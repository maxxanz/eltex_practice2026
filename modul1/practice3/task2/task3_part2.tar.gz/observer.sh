#!/bin/bash

CONFIG_FILE="observer.conf"
LOG_FILE="observer.log"

# Функция логирования
log_message() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG_FILE"
}

# Проверяем файл конфигурации
if [ ! -f "$CONFIG_FILE" ]; then
    log_message "Файл конфигурации $CONFIG_FILE не найден!"
    exit 1
fi

# Получаем абсолютный путь к директории
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Читаем конфигурацию
while IFS= read -r SCRIPT_PATH; do
    # Пропускаем пустые строки и комментарии
    if [ -z "$SCRIPT_PATH" ] || [[ "$SCRIPT_PATH" =~ ^# ]]; then
        continue
    fi
    
    # Если путь не абсолютный, делаем его абсолютным
    if [[ ! "$SCRIPT_PATH" =~ ^/ ]]; then
        SCRIPT_PATH="$SCRIPT_DIR/$SCRIPT_PATH"
    fi
    
    SCRIPT_NAME=$(basename "$SCRIPT_PATH")
    
    # Ищем процесс с помощью pgrep по полному имени
    # Используем -f для поиска в командной строке
    if pgrep -f "$SCRIPT_NAME" > /dev/null; then
        log_message "Процесс $SCRIPT_NAME уже запущен"
    else
        log_message "Запуск: $SCRIPT_PATH"
        # Проверяем, что файл существует и исполняемый
        if [ -f "$SCRIPT_PATH" ] && [ -x "$SCRIPT_PATH" ]; then
            cd "$SCRIPT_DIR" && nohup "$SCRIPT_PATH" >> /dev/null 2>&1 &
            sleep 1  # Даем время запуститься
        else
            log_message "Ошибка: $SCRIPT_PATH не найден или не исполняемый"
        fi
    fi
done < "$CONFIG_FILE"

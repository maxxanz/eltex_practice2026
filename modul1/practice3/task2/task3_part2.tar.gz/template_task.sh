#!/bin/bash

# Получаем имя скрипта без пути
SCRIPT_NAME=$(basename "$0")

# --- Проверка: если имя шаблонное, выходим ---
if [ "$SCRIPT_NAME" == "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

# --- Настройки для общения с cuckoo ---
PIPE_DIR="/tmp/run"
PIPE_NAME="cuckoo.pid"
PIPE_PATH="$PIPE_DIR/$PIPE_NAME"

# --- Проверяем, что канал существует ---
if [ ! -p "$PIPE_PATH" ]; then
    echo "Ошибка: канал $PIPE_PATH не существует. Запустите cuckoo.sh сначала!"
    exit 1
fi

# --- 1. Пишем в лог о запуске ---
LOG_FILE="report_${SCRIPT_NAME%.*}.log"
echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт запущен" >> "$LOG_FILE"

# --- 2. Запрашиваем время у cuckoo ---
REQUEST="${SCRIPT_NAME}[$$]: how much time do I have?"

# Отправляем запрос в канал и сразу читаем ответ
echo "$REQUEST" > "$PIPE_PATH"
read -r N < "$PIPE_PATH"

# Проверяем, что N - число
if ! [[ "$N" =~ ^[0-9]+$ ]]; then
    echo "Ошибка: получено не число: $N" >> "$LOG_FILE"
    exit 1
fi

# --- 3. Ждем N секунд ---
sleep "$N"

# --- 4. Пишем в лог о завершении ---
echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт завершился, работал $N секунд." >> "$LOG_FILE"

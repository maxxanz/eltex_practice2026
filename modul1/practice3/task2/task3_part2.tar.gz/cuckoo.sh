#!/bin/bash

# --- Настройки ---
PIPE_DIR="/tmp/run"
PIPE_NAME="cuckoo.pid"
PIPE_PATH="$PIPE_DIR/$PIPE_NAME"
LOG_FILE="cuckoo.log"

# --- Создаем папку и канал ---
mkdir -p "$PIPE_DIR"
rm -f "$PIPE_PATH"
mkfifo "$PIPE_PATH"

# --- Записываем в лог о запуске ---
echo "$(date '+%Y-%m-%d %H:%M:%S') Startup!" >> "$LOG_FILE"

# --- Функция завершения ---
shutdown() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') Shutdown!" >> "$LOG_FILE"
    rm -f "$PIPE_PATH"
    exit 0
}

trap shutdown SIGUSR1 SIGTERM SIGINT

# --- Основной цикл ---
while true; do
    # Открываем канал для чтения
    if [ -p "$PIPE_PATH" ]; then
        # Читаем запрос
        if read -r request < "$PIPE_PATH"; then
            # Проверяем формат запроса
            if [[ "$request" =~ ^([^\[]+)\[([0-9]+)\]: ]]; then
                NAME="${BASH_REMATCH[1]}"
                PID="${BASH_REMATCH[2]}"
                
                # Генерируем число от 2 до 10
                N=$(( (RANDOM % 9) + 2 ))
                
                # Отправляем ответ в канал (с другой стороны)
                echo "$N" > "$PIPE_PATH"
                
                # Логируем
                echo "$(date '+%Y-%m-%d %H:%M:%S') ${NAME}[${PID}] ${N}" >> "$LOG_FILE"
            else
                echo "Ошибка формата: $request" >> "$LOG_FILE"
            fi
        fi
    else
        echo "Канал $PIPE_PATH не существует!" >> "$LOG_FILE"
        sleep 1
    fi
done
